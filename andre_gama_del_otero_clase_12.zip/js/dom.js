const cart = document.querySelector(".cart");
const cart__contenido = document.querySelector(".cart__contenido");
const car = document.querySelector(".cantidad");
const wraper__cta = document.querySelector(".wraper__cta");
const wraper__titles = document.querySelector(".wraper__titles");
const vaciar__carrito = document.querySelector(".cta__clear");
const padreCarrito = document.querySelector(".wraper__content");

//logueo y registro de usuarios
const logueo = document.querySelector("#logueo");
const logueoToggle = document.querySelector(".logueo");

const nombreLogueo = document.querySelector("#nombreLogueo");
const claveLogueo = document.querySelector("#claveLogueo");
const claveLogueoRepetir = document.querySelector("#claveLogueoRepetir");

const errorNombre = document.querySelector("#errorNombre");
const errorClave = document.querySelector("#errorClave");
const errorRepetirClave = document.querySelector("#errorRepetirClave");
const usuarioIn = document.querySelector("#user");
const contenidoMenuUsuario = document.querySelector(".menuUser");

const infoLogueo = document.querySelector(".infoLogueo");
const botonLogueo = document.querySelector(".boton--logueo");
const botonRegistro = document.querySelector(".boton--registro");
const botonConfirmar = document.querySelector(".boton--confirmar");
const cerrarSesion = document.querySelector(".cerrarSesion");

const modal = document.querySelector("#modal");