const cart = document.querySelector(".cart");
const cart__contenido = document.querySelector(".cart__contenido");
const car = document.querySelector(".cantidad");
const wraper__cta = document.querySelector(".wraper__cta");
const wraper__titles = document.querySelector(".wraper__titles");
const clear__localStorage = document.querySelector(".cta__clear");
const padreCarrito = document.querySelector(".wraper__content");